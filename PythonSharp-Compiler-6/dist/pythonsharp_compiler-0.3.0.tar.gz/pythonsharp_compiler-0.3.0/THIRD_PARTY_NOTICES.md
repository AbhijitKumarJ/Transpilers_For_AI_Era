# Third-Party Notices

This repository (`pythonsharp-compiler`) is licensed under the **MIT License** (see `LICENSE`).

Certain ambient standard library declaration files (`.d.ps`) distributed under `stdlib/` incorporate type signatures, class hierarchies, parameter names, or documentation derived from upstream open-source stub definitions and API specifications. Those upstream notices and license texts are reproduced below.

> **Note on User-Generated Stubs (`.ps-stubs/`):**  
> Stubs generated locally by users via `psc bindgen` into `.ps-stubs/` (ignored by Git and excluded from compiler wheels) are derived from packages installed in the user's own Python environment and remain subject to the upstream licenses of their respective source packages.

---

## 1. Typeshed (`python/typeshed`)

* **Applies to:** `stdlib/01_python_stdlib/**`, `stdlib/03_typeshed_replica/**`
* **Upstream Repository:** https://github.com/python/typeshed
* **License:** Dual-licensed under the **Apache License 2.0** and the **MIT License** (redistributed here under the MIT License)

```text
Copyright (c) 2015-present Python Software Foundation and Typeshed contributors

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
```

*(Upstream Typeshed is also available under the Apache License, Version 2.0: http://www.apache.org/licenses/LICENSE-2.0)*

---

## 2. Scientific, Data & AI Ecosystem API Declarations (`stdlib/02_scientific_and_ai/`)

The curated Triple-Surface declaration bundles in `stdlib/02_scientific_and_ai/` (`01_numpy` through `13_faiss_onnxruntime`) reference public API signatures, parameter conventions, and docstrings from the following open-source projects:

| Bundle Directory | Upstream Project(s) | Upstream License | Copyright Notice |
| --- | --- | --- | --- |
| `01_numpy/` | **NumPy** (`numpy`) | BSD-3-Clause | Copyright (c) 2005-2026, NumPy Developers |
| `02_scipy/` | **SciPy** (`scipy`) | BSD-3-Clause | Copyright (c) 2001-2002 Enthought, Inc.; 2003-2026, SciPy Developers |
| `03_pandas/` | **pandas** (`pandas` / `pandas-stubs`) | BSD-3-Clause | Copyright (c) 2008-2011, AQR Capital Management, LLC, Lambda Foundry, Inc. and PyData Development Team; 2011-2026, Open source contributors |
| `04_matplotlib_seaborn/` | **Matplotlib** (`matplotlib`)<br>**Seaborn** (`seaborn`) | PSF-based Matplotlib License<br>BSD-3-Clause | Copyright (c) 2012-2026 Matplotlib Development Team<br>Copyright (c) 2012-2026, Michael L. Waskom |
| `05_sklearn/` | **scikit-learn** (`scikit-learn`) | BSD-3-Clause | Copyright (c) 2007-2026, The scikit-learn developers |
| `06_torch/` | **PyTorch** (`torch`) | BSD-3-Clause | Copyright (c) 2016-2026, Facebook, Inc. / PyTorch Contributors |
| `07_sympy/` | **SymPy** (`sympy`) | BSD-3-Clause | Copyright (c) 2006-2026 SymPy Development Team |
| `08_qiskit/` | **Qiskit** (`qiskit`) | Apache-2.0 | Copyright (c) 2017-2026, Qiskit Development Team |
| `09_polars/` | **Polars** (`polars`) | MIT | Copyright (c) 2020-2026 Ritchie Vink |
| `10_xgboost_lightgbm/` | **XGBoost** (`xgboost`)<br>**LightGBM** (`lightgbm`) | Apache-2.0<br>MIT | Copyright (c) 2014-2026, XGBoost Contributors<br>Copyright (c) 2016-2026, Microsoft Corporation |
| `11_optuna/` | **Optuna** (`optuna`) | MIT | Copyright (c) 2018-2026, Preferred Networks, Inc. |
| `12_transformers/` | **Hugging Face Transformers** (`transformers`) | Apache-2.0 | Copyright (c) 2018-2026, The Hugging Face team |
| `13_faiss_onnxruntime/` | **FAISS** (`faiss`)<br>**ONNX Runtime** (`onnxruntime`) | MIT<br>MIT | Copyright (c) Meta Platforms, Inc. and affiliates<br>Copyright (c) Microsoft Corporation |

---

### BSD 3-Clause License (NumPy, SciPy, pandas, Seaborn, scikit-learn, PyTorch, SymPy)

```text
Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice, this
   list of conditions and the following disclaimer.

2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

3. Neither the name of the copyright holder nor the names of its
   contributors may be used to endorse or promote products derived from
   this software without specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
```

---

### Matplotlib License (PSF-Compatible)

> **Summary of Modifications (pursuant to Clause 3):**  
> Automated AST translation from upstream Python `.pyi` type stubs into PythonSharp `.d.ps` ambient declaration bundles via `psc bindgen` / `psc stubgen`.

```text
1. This LICENSE AGREEMENT is between the Matplotlib Development Team
("MDT"), and the Individual or Organization ("Licensee") accessing and
otherwise using matplotlib software in source or binary form and its
associated documentation.

2. Subject to the terms and conditions of this License Agreement, MDT
hereby grants Licensee a nonexclusive, royalty-free, world-wide license
to reproduce, analyze, test, perform and/or display publicly, prepare
derivative works, distribute, and otherwise use matplotlib
alone or in any derivative version, provided, however, that MDT's
License Agreement and MDT's notice of copyright, i.e., "Copyright (c)
2012-2026 Matplotlib Development Team; All Rights Reserved" are retained in
matplotlib alone or in any derivative version prepared by Licensee.

3. In the event Licensee prepares a derivative work that is based on or
incorporates matplotlib or any part thereof, and wants to make the
derivative work available to others as provided herein, then Licensee
hereby agrees to include in any such work a brief summary of the changes
made to matplotlib.

4. MDT is making matplotlib available to Licensee on an "AS IS"
basis. MDT MAKES NO REPRESENTATIONS OR WARRANTIES, EXPRESS OR
IMPLIED. BY WAY OF EXAMPLE, BUT NOT LIMITATION, MDT MAKES NO AND
DISCLAIMS ANY REPRESENTATION OR WARRANTY OF MERCHANTABILITY OR FITNESS
FOR ANY PARTICULAR PURPOSE OR THAT THE USE OF MATPLOTLIB WILL NOT
INFRINGE ANY THIRD PARTY RIGHTS.

5. MDT SHALL NOT BE LIABLE TO LICENSEE OR ANY OTHER USERS OF MATPLOTLIB
FOR ANY INCIDENTAL, SPECIAL, OR CONSEQUENTIAL DAMAGES OR LOSS AS A RESULT
OF MODIFYING, DISTRIBUTING, OR OTHERWISE USING MATPLOTLIB, OR ANY
DERIVATIVE THEREOF, EVEN IF ADVISED OF THE POSSIBILITY THEREOF.

6. This License Agreement will automatically terminate upon a material
breach of its terms and conditions.

7. Nothing in this License Agreement shall be deemed to create any
relationship of agency, partnership, or joint venture between MDT and
Licensee. This License Agreement does not grant permission to use MDT
trademarks or trade name in a trademark sense to endorse or promote
products or services of Licensee, or any third party.

8. By copying, installing or otherwise using matplotlib, Licensee
agrees to be bound by the terms and conditions of this License
Agreement.
```

---

### Apache License, Version 2.0 (Qiskit, XGBoost, Transformers)

```text
Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
```
