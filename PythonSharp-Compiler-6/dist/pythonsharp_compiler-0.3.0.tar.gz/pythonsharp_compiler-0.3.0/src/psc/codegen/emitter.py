from __future__ import annotations

import ast
import importlib.util
import json
import marshal
import struct
import sys
import time
import types
from dataclasses import dataclass
from pathlib import Path

from psc.codegen.declaration_emitter import DeclarationEmitter
from psc.codegen.py_ast_builder import PythonAstBuilder
from psc.codegen.topo_sorter import NamespacePackagePlanner, PlannedPythonModule
from psc.frontend.ast_nodes import CompilationUnit
from psc.semantics.symbols import GlobalSymbolTable


@dataclass(slots=True)
class EmittedArtifact:
    """Represents a compiled Python module and its line-pinned bytecode artifact."""

    namespace: tuple[str, ...]
    module_rel_path: str
    py_path: Path
    pyc_path: Path | None
    pycache_pyc_path: Path | None
    d_ps_path: Path | None = None
    py_source: str = ""
    code_object: types.CodeType | None = None
    primary_ps_filename: str = ""


class ArtifactEmitter:
    """
    Pass 3B — Python 3.11+ Package & Line-Pinned PEP 552 `.pyc` Bytecode Emitter:
      1. Emits formatted Python 3.11+ source files (`.py`) grouped by logical namespace,
         automatically creating intermediate `__init__.py` package markers.
      2. Compiles the `.ps`-span-stamped `ast.Module` directly into a Python `CodeType`
         object before unparsing—preserving the exact `.ps` line numbers (`lineno`) and
         pinning `co_filename` on every function/class code object to its originating
         `.ps` source file.
      3. Writes PEP 552 `.pyc` files (both standalone `<module>.pyc` and inside
         `__pycache__/<stem>.cpython-<XY>.pyc`) so CPython runtime stack traces
         natively display `File "Services/OrderCache.ps", line 24` with zero runtime hooks.
    """

    def __init__(
        self,
        symtab: GlobalSymbolTable,
        target_units: list[CompilationUnit] | None = None,
    ) -> None:
        self.symtab = symtab
        self.target_units = target_units
        self.ast_builder = PythonAstBuilder(symtab)

    def emit_all(
        self,
        out_dir: Path,
        emit_pyc: bool = True,
    ) -> list[EmittedArtifact]:
        out_dir = out_dir.resolve()
        out_dir.mkdir(parents=True, exist_ok=True)

        planner = NamespacePackagePlanner(self.symtab, target_units=self.target_units)
        planned_modules = planner.plan_modules()
        artifacts: list[EmittedArtifact] = []

        for rel_path, planned in sorted(planned_modules.items()):
            artifact = self.emit_module(planned, out_dir=out_dir, emit_pyc=emit_pyc)
            artifacts.append(artifact)

        self.write_manifest(out_dir, artifacts)
        return artifacts

    @staticmethod
    def write_manifest(out_dir: Path, artifacts: list[EmittedArtifact]) -> Path:
        """Writes a deterministic build manifest with no absolute paths or timestamps."""
        from psc import LANGUAGE_VERSION, __version__

        out_dir = out_dir.resolve()
        modules = []
        for artifact in sorted(artifacts, key=lambda item: item.module_rel_path):
            entry: dict[str, object] = {
                "namespace": list(artifact.namespace),
                "module": artifact.module_rel_path,
                "primary_ps": artifact.primary_ps_filename,
                "py": artifact.py_path.relative_to(out_dir).as_posix(),
                "pyc": (artifact.pyc_path.relative_to(out_dir).as_posix() if artifact.pyc_path is not None else None),
                "d_ps": (artifact.d_ps_path.relative_to(out_dir).as_posix() if artifact.d_ps_path is not None else None),
            }
            modules.append(entry)

        manifest = {
            "schema_version": 1,
            "compiler_version": __version__,
            "language_version": LANGUAGE_VERSION,
            "modules": modules,
        }
        manifest_path = out_dir / "psc-manifest.json"
        manifest_path.write_text(
            json.dumps(manifest, indent=2, sort_keys=True) + "\n",
            encoding="utf-8",
        )
        return manifest_path

    def emit_module(
        self,
        planned: PlannedPythonModule,
        out_dir: Path,
        emit_pyc: bool = True,
    ) -> EmittedArtifact:
        module_ast = self.ast_builder.build_module(planned)

        # Build a map of class/method names -> originating `.ps` filename in case
        # multiple `.ps` files contributed types to the same logical namespace.
        qualname_to_ps_file: dict[str, str] = {}
        for type_sym in planned.types:
            ps_file = type_sym.span.ps_filename
            qualname_to_ps_file[type_sym.name] = ps_file

        # 1. Compile the `.ps`-line-stamped `ast.Module` BEFORE `ast.unparse` so
        #    every bytecode instruction retains its exact `.ps` `lineno` and `col_offset`!
        raw_code = compile(
            module_ast,
            filename=planned.primary_ps_filename,
            mode="exec",
            dont_inherit=True,
        )
        pinned_code = self._pin_nested_code_filenames(
            raw_code,
            default_ps_filename=planned.primary_ps_filename,
            qualname_to_ps_file=qualname_to_ps_file,
        )

        # 2. Generate clean, human-readable Python 3.11+ source code
        header = f"# Auto-generated by PythonSharp (psc) — Bytecode line-pinned to {planned.primary_ps_filename}\n"
        py_source = header + ast.unparse(module_ast) + "\n"

        py_path = out_dir / planned.module_rel_path
        py_path.parent.mkdir(parents=True, exist_ok=True)
        self._ensure_package_init_files(out_dir, py_path.parent)
        py_path.write_text(py_source, encoding="utf-8")

        pyc_path: Path | None = None
        pycache_pyc_path: Path | None = None

        if emit_pyc:
            stat = py_path.stat()
            mtime = int(stat.st_mtime)
            source_size = stat.st_size & 0xFFFFFFFF
            pyc_bytes = self.build_pep552_pyc_bytes(pinned_code, mtime=mtime, source_size=source_size)

            # Write standalone `<module>.pyc`
            pyc_path = py_path.with_suffix(".pyc")
            pyc_path.write_bytes(pyc_bytes)

            # Also write PEP 3147 `__pycache__/<stem>.<cache_tag>.pyc` so standard
            # `import <package.module>` loads our `.ps`-pinned bytecode!
            cache_tag = sys.implementation.cache_tag or f"cpython-{sys.version_info.major}{sys.version_info.minor}"
            pycache_dir = py_path.parent / "__pycache__"
            pycache_dir.mkdir(parents=True, exist_ok=True)
            pycache_pyc_path = pycache_dir / f"{py_path.stem}.{cache_tag}.pyc"
            pycache_pyc_path.write_bytes(pyc_bytes)

        # 3. Generate strongly-typed ambient declaration header (`.d.ps`)
        d_ps_path = DeclarationEmitter.emit_module_declaration(planned, out_dir=out_dir)

        return EmittedArtifact(
            namespace=planned.namespace,
            module_rel_path=planned.module_rel_path,
            py_path=py_path,
            pyc_path=pyc_path,
            pycache_pyc_path=pycache_pyc_path,
            d_ps_path=d_ps_path,
            py_source=py_source,
            code_object=pinned_code,
            primary_ps_filename=planned.primary_ps_filename,
        )

    @classmethod
    def _pin_nested_code_filenames(
        cls,
        code_obj: types.CodeType,
        default_ps_filename: str,
        qualname_to_ps_file: dict[str, str],
        active_ps_filename: str | None = None,
    ) -> types.CodeType:
        """
        Recursively walks `code_obj.co_consts` and pins `co_filename` on every nested
        class and function `CodeType` object to the exact `.ps` file that declared it.
        """
        target_file = qualname_to_ps_file.get(code_obj.co_name, active_ps_filename or default_ps_filename)
        new_consts = []
        changed = code_obj.co_filename != target_file

        for const in code_obj.co_consts:
            if isinstance(const, types.CodeType):
                pinned_child = cls._pin_nested_code_filenames(
                    const,
                    default_ps_filename=default_ps_filename,
                    qualname_to_ps_file=qualname_to_ps_file,
                    active_ps_filename=target_file,
                )
                if pinned_child is not const:
                    changed = True
                new_consts.append(pinned_child)
            else:
                new_consts.append(const)

        if changed:
            return code_obj.replace(
                co_filename=target_file,
                co_consts=tuple(new_consts),
            )
        return code_obj

    @staticmethod
    def build_pep552_pyc_bytes(
        code_obj: types.CodeType,
        mtime: int | None = None,
        source_size: int = 0,
    ) -> bytes:
        """
        Constructs a standard 16-byte PEP 552 timestamp-invalidated `.pyc` payload:
          - 4 bytes: `importlib.util.MAGIC_NUMBER`
          - 4 bytes: bitfield (`0` = timestamp-based invalidation)
          - 4 bytes: 32-bit timestamp (`mtime`)
          - 4 bytes: 32-bit source file size (`source_size`)
          - N bytes: `marshal.dumps(code_obj)`
        """
        ts = int(time.time()) if mtime is None else (mtime & 0xFFFFFFFF)
        header = importlib.util.MAGIC_NUMBER + struct.pack("<III", 0, ts, source_size & 0xFFFFFFFF)
        return header + marshal.dumps(code_obj)

    @staticmethod
    def load_code_from_pyc(pyc_path: Path) -> types.CodeType:
        """Loads and unmarshals the `CodeType` object from a 16-byte header `.pyc` file."""
        raw = pyc_path.read_bytes()
        code_obj = marshal.loads(raw[16:])
        assert isinstance(code_obj, types.CodeType)
        return code_obj

    @staticmethod
    def _ensure_package_init_files(root_out_dir: Path, target_dir: Path) -> None:
        curr = target_dir.resolve()
        root = root_out_dir.resolve()
        while curr != root and root in curr.parents:
            init_file = curr / "__init__.py"
            if not init_file.exists():
                init_file.write_text("# Auto-generated PythonSharp package\n", encoding="utf-8")
            curr = curr.parent
