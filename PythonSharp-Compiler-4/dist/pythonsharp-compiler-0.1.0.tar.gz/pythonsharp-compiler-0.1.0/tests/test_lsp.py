from __future__ import annotations

import io
from typing import Any, cast

from psc.lsp.server import LanguageServer


def test_lsp_initialize_and_shutdown() -> None:
    in_buf = io.BytesIO()
    out_buf = io.BytesIO()
    server = LanguageServer(in_stream=in_buf, out_stream=out_buf)

    init_req = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": "initialize",
        "params": {"capabilities": {}},
    }
    resp = server.handle_request(init_req)
    assert resp is not None
    assert resp["id"] == 1
    res = cast(dict[str, Any], resp["result"])
    assert "capabilities" in res
    assert res["capabilities"]["hoverProvider"] is True
    assert res["capabilities"]["definitionProvider"] is True

    shutdown_req = {
        "jsonrpc": "2.0",
        "id": 2,
        "method": "shutdown",
        "params": None,
    }
    resp2 = server.handle_request(shutdown_req)
    assert resp2 is not None
    assert resp2["result"] is None

    server.handle_notification({"jsonrpc": "2.0", "method": "exit", "params": None})
    assert server.is_running is False


def test_lsp_diagnostics_on_open() -> None:
    out_buf = io.BytesIO()
    server = LanguageServer(in_stream=io.BytesIO(), out_stream=out_buf)

    # Valid code: 0 errors
    valid_source = "namespace TestApp; public class Greeter { public string Name { get; set; } }"
    server.handle_notification({
        "jsonrpc": "2.0",
        "method": "textDocument/didOpen",
        "params": {
            "textDocument": {
                "uri": "file:///workspace/Greeter.ps",
                "text": valid_source,
            }
        },
    })

    assert len(server.notifications_log) == 1
    notif = server.notifications_log[0]
    assert notif["method"] == "textDocument/publishDiagnostics"
    params = cast(dict[str, Any], notif["params"])
    assert params["uri"] == "file:///workspace/Greeter.ps"
    assert len(params["diagnostics"]) == 0

    # Code with syntax error: triggers diagnostic
    broken_source = "namespace TestApp; public class Broken { void foo( }"
    server.handle_notification({
        "jsonrpc": "2.0",
        "method": "textDocument/didOpen",
        "params": {
            "textDocument": {
                "uri": "file:///workspace/Broken.ps",
                "text": broken_source,
            }
        },
    })
    assert len(server.notifications_log) == 2
    broken_notif = server.notifications_log[1]
    broken_params = cast(dict[str, Any], broken_notif["params"])
    assert len(broken_params["diagnostics"]) > 0
    d0 = broken_params["diagnostics"][0]
    assert "range" in d0
    assert d0["severity"] == 1


def test_lsp_hover_and_definition() -> None:
    server = LanguageServer(in_stream=io.BytesIO(), out_stream=io.BytesIO())
    source = """namespace MyApp;

public class OrderService
{
    public void Process() {}
}
"""
    uri = "file:///workspace/OrderService.ps"
    server.handle_notification({
        "jsonrpc": "2.0",
        "method": "textDocument/didOpen",
        "params": {
            "textDocument": {
                "uri": uri,
                "text": source,
            }
        },
    })

    # Hover over 'class' keyword on line 3 (line index 2, char index 8)
    hover_req = {
        "jsonrpc": "2.0",
        "id": 10,
        "method": "textDocument/hover",
        "params": {
            "textDocument": {"uri": uri},
            "position": {"line": 2, "character": 8},
        },
    }
    resp = server.handle_request(hover_req)
    assert resp is not None
    assert resp["result"] is not None
    res = cast(dict[str, Any], resp["result"])
    assert "class" in res["contents"]["value"]

    # Hover over OrderService identifier on line 3 (character 15)
    hover_cls_req = {
        "jsonrpc": "2.0",
        "id": 11,
        "method": "textDocument/hover",
        "params": {
            "textDocument": {"uri": uri},
            "position": {"line": 2, "character": 15},
        },
    }
    resp_cls = server.handle_request(hover_cls_req)
    assert resp_cls is not None
    res_cls = cast(dict[str, Any], resp_cls["result"])
    assert "OrderService" in res_cls["contents"]["value"]

    # Go-to-definition for OrderService
    def_req = {
        "jsonrpc": "2.0",
        "id": 12,
        "method": "textDocument/definition",
        "params": {
            "textDocument": {"uri": uri},
            "position": {"line": 2, "character": 15},
        },
    }
    def_resp = server.handle_request(def_req)
    assert def_resp is not None
    def_res = cast(dict[str, Any], def_resp["result"])
    assert def_res["uri"] == uri
    assert def_res["range"]["start"]["line"] == 2


def test_lsp_completion() -> None:
    server = LanguageServer(in_stream=io.BytesIO(), out_stream=io.BytesIO())
    comp_req = {
        "jsonrpc": "2.0",
        "id": 20,
        "method": "textDocument/completion",
        "params": {
            "textDocument": {"uri": "file:///workspace/Test.ps"},
            "position": {"line": 0, "character": 0},
        },
    }
    resp = server.handle_request(comp_req)
    assert resp is not None
    res = cast(dict[str, Any], resp["result"])
    items = res["items"]
    labels = {it["label"] for it in items}
    assert "class" in labels
    assert "interface" in labels
    assert "record" in labels
    assert "String" in labels
    assert "IEnumerable" in labels
